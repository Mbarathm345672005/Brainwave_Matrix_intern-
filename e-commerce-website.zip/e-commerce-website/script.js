let cart = [];

// Array of image URLs for each product
const productImages = {
    product1: [
        'https://via.placeholder.com/200/FF0000/FFFFFF?text=Product+1+Image+1',
        'https://via.placeholder.com/200/00FF00/FFFFFF?text=Product+1+Image+2',
        'https://via.placeholder.com/200/0000FF/FFFFFF?text=Product+1+Image+3',
    ],
    product2: [
        'https://via.placeholder.com/200/FFFF00/FFFFFF?text=Product+2+Image+1',
        'https://via.placeholder.com/200/FF00FF/FFFFFF?text=Product+2+Image+2',
        'https://via.placeholder.com/200/00FFFF/FFFFFF?text=Product+2+Image+3',
    ],
    product3: [
        'https://via.placeholder.com/200/FF8000/FFFFFF?text=Product+3+Image+1',
        'https://via.placeholder.com/200/8000FF/FFFFFF?text=Product+3+Image+2',
        'https://via.placeholder.com/200/0080FF/FFFFFF?text=Product+3+Image+3',
    ],
    product4: [
        'https://via.placeholder.com/200/00FF80/FFFFFF?text=Product+4+Image+1',
        'https://via.placeholder.com/200/800000/FFFFFF?text=Product+4+Image+2',
        'https://via.placeholder.com/200/808000/FFFFFF?text=Product+4+Image+3',
    ]
};

// Function to add items to the cart
function addToCart(productName, productPrice) {
    const product = {
        name: productName,
        price: productPrice
    };
    cart.push(product);
    alert(`${productName} has been added to your cart!`);
    updateCartCount();
}

// Function to update cart count
function updateCartCount() {
    const cartCount = cart.length;
    document.getElementById('cartCount').innerText = `(${cartCount})`;
}

// Function to show product details in a modal
function showProductDetails(product, productId) {
    const modal = document.getElementById('productModal');
    modal.style.display = 'block';
    const randomImageIndex = Math.floor(Math.random() * productImages[productId].length);
    const imageUrl = productImages[productId][randomImageIndex];

    modal.querySelector('.modal-content').innerHTML = `
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>${product.name}</h2>
        <img src="${imageUrl}" alt="${product.name}">
        <p>${product.description}</p>
        <p>Price: $${product.price}</p>
        <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>
    `;
}

// Function to close the modal
function closeModal() {
    document.getElementById('productModal').style.display = 'none';
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById('productModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}
